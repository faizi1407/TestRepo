#
# Cookbook Name:: mysqltest
# Recipe:: default
#
# Copyright 2016, YOUR_COMPANY_NAME
#
# All rights reserved - Do Not Redistribute
#
include_recipe 'apt'
#include_recipe 'java'
# make sure we have java installed


include_recipe 'chef-sugar::default'

if docker?
  # Jenkins is already running
  service 'jenkins' do
    start_command   '/usr/bin/sv start jenkins'
    stop_command    '/usr/bin/sv stop jenkins'
    restart_command '/usr/bin/sv restart jenkins'
    status_command  '/usr/bin/sv status jenkins'
    action :nothing
  end
else
  include_recipe 'jenkins::java'
  include_recipe 'jenkins::master'
end



mysql_service 'example' do
version '5.5'
  bind_address '0.0.0.0'
  port '3306'
  data_dir '/data'
  initial_root_password 'Ch4ng3me'
  action [:create, :start]
end

mysql_config 'extra' do
  instance 'example'
  source 'extra.cnf.erb'
  notifies :restart, 'mysql_service[example]'
  action :create
end 

# make sure we have java installed


# Install Tomcat 8.0.32 to the default location
tomcat_install 'helloworld' do
  version '8.0.32'
end


package 'libapache2-mod-jk' do
  case node['platform_family']
  when 'rhel', 'fedora', 'suse'
    package_name 'mod_jk'
  else
    package_name 'libapache2-mod-jk'
  end
end
apache_module 'jk'

