packagecloud
===============
This is the Changelog for the packagecloud cookbook

v0.2.0 (2015-02-17)
-------------------
Rework GPG paths to support new GPG endpoints for repos with repo-specific GPG
keys. Old endpoints/URLs still work, too.


v0.0.1 (2014-06-05)
-------------------
Initial release.


v0.0.1 (2014-06-05)
-------------------
Initial release!
