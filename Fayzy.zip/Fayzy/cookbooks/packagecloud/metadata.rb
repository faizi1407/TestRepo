name 'packagecloud'
maintainer 'Joe Damato'
maintainer_email 'joe@packagecloud.io'
license 'Apache 2.0'
description 'Installs/Configures packagecloud.io repositories.'
long_description 'Installs/Configures packagecloud.io repositories.'
version '0.2.0'
source_url 'https://github.com/computology/packagecloud-cookbook' if respond_to?(:source_url)
issues_url 'https://github.com/computology/packagecloud-cookbook/issues' if respond_to?(:issues_url)
