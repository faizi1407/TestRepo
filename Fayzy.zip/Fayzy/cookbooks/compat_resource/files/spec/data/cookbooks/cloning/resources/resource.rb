provides :resource
resource_name :resource
