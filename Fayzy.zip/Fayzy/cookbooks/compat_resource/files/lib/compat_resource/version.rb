module CompatResource
  VERSION = '12.10.3'
end
